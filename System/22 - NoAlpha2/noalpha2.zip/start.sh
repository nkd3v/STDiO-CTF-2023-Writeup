#!/bin/sh

for file in /usr/bin/*; do
    if [[ $file == *.* ]]; then
        newname="${file%%.*}"
        mv "$file" "$newname"
    fi
done
DB_PASS=$(cat /dev/urandom | tr -cd 'a-f0-9' | head -c 32)
mv /pg_hba.conf /etc/postgresql/14/main/pg_hba.conf
sed -i "s/TMP_FLAG/$FLAG/g" /flag.sql
sed -i "s/TMP_PASSWORD/$DB_PASS/g" /flag.sql /home/ctf/flag.txt
/etc/init.d/postgresql start
sudo -u postgres psql -f /flag.sql
rm /flag.sql
unset FLAG
unset DB_PASS
/etc/init.d/postgresql restart
/etc/init.d/xinetd start
sleep infinity