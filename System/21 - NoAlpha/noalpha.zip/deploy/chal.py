import re
import subprocess

while True:
    cmd = input('$ ')
    allowed_commands = ['echo', 'whoami', 'uname'] # TODO: Add other 'safe' commands

    check = cmd

    for command in allowed_commands:
        check = check.replace(command, '')

    if re.search(r'[a-zA-Z0-9!]', check) is None:
        try:
            subprocess.run(cmd, shell=True, executable='/bin/bash', env={'HOME':'/home/ctf'})
        except:
            print("?")
    else:
        print("Nope.")