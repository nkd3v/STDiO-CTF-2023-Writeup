from gevent.pywsgi import WSGIServer
from flask import Flask, request, render_template, redirect
from Crypto.Util.number import getStrongPrime, bytes_to_long, long_to_bytes
import os
app = Flask(__name__)

FLAG = os.environ.get('FLAG') or 'STDIOXX{https://youtu.be/dQw4w9WgXcQ}'
ENV = os.environ.get('ENV') or 'prod'
PRIVATE_KEY_P = int(os.environ.get('PRIVATE_KEY_P')) or getStrongPrime(512)
PRIVATE_KEY_Q = int(os.environ.get('PRIVATE_KEY_Q')) or getStrongPrime(512)

p = PRIVATE_KEY_P
q = PRIVATE_KEY_Q
e = 0x10001
n = p * q
d = pow(e, -1, (p - 1) * (q - 1))


@app.route('/')
def index():
    return render_template('index.html', result='')


@app.route('/very_secret_endpoint', methods=['POST'])
def secret():
    secret = pow(bytes_to_long(FLAG.encode()), e, n)
    return render_template('index.html', result=secret)


@app.route('/encrypt', methods=['POST'])
def encrypt():
    num = request.form.get('input_num')
    if num.isdigit():
        enc = pow(int(num), e, n)
        return render_template('index.html', result=enc)
    else:
        return render_template('index.html', result='Please Enter Only Numbers !!')


@app.route('/decrypt', methods=['POST'])
def decrypt():
    num = request.form.get('input_num')
    if num.isdigit():
        dec = pow(int(num), d, n)
        dec_text = long_to_bytes(dec)
        if b'STDIO' not in dec_text:
            return render_template('index.html', result=dec)
        else:
            return redirect('https://youtu.be/dQw4w9WgXcQ')
    else:
        return render_template('index.html', result='Please Enter Only Numbers !!')


if __name__ == '__main__':
    if ENV == 'dev':
        app.run(host='0.0.0.0', port=1337, debug=True)
    else:
        http_server = WSGIServer(('0.0.0.0', 1337), app)
        http_server.serve_forever()
